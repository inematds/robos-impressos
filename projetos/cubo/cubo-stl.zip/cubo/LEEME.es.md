Archivos del robot cuadrado de mesa (robos-impressos).

Carpeta stl = una pieza por archivo, ya colocada en la posición de impresión. Carpeta mesas = archivos 3MF con las piezas ya organizadas por color. Carpeta firmware = programa de Arduino que pone los servos en el centro.

Guías de este zip, en orden de uso:

1. [IMPRIMIR.es.md](IMPRIMIR.es.md): cómo imprimir. Empieza por la mesa 06, que tiene el cupón de prueba.
2. [LISTA-DE-COMPRAS.es.md](LISTA-DE-COMPRAS.es.md): qué comprar, con cantidad, precio estimado y enlace.
3. [LIGACAO.es.md](LIGACAO.es.md): cómo conectar los cables, con el esquema y los preparativos de la mesa de trabajo. El programa de Arduino está en la carpeta firmware.

Guía en internet: https://inematds.github.io/robos-impressos/guia/es/cubo/
