Arquivos do dinossauro (robos-impressos).

Pasta stl = uma peça por arquivo, já deitada na posição de impressão. Pasta mesas = arquivos 3MF com as peças já arrumadas por cor. Pasta firmware = programa do Arduino que põe os servos no centro.

Guias deste zip, na ordem de uso:

1. [IMPRIMIR.md](IMPRIMIR.md): como imprimir. Comece pela mesa 05, que tem o cupom de teste.
2. [LISTA-DE-COMPRAS.md](LISTA-DE-COMPRAS.md): o que comprar, com quantidade, preço estimado e link.
3. [LIGACAO.md](LIGACAO.md): como ligar os fios, com o esquema e os preparos da bancada. O programa do Arduino está na pasta firmware.

Guia na internet: https://inematds.github.io/robos-impressos/guia/dino/
