Dinosaur files (robos-impressos).

The stl folder has one part per file, already laid out in its print position. The mesas folder has 3MF files with the parts arranged by color. The firmware folder has the Arduino program that moves the servos to the center.

Guides in this zip, in order of use:

1. [IMPRIMIR.en.md](IMPRIMIR.en.md): how to print. Start with build plate 05, which has the test coupon.
2. [LISTA-DE-COMPRAS.en.md](LISTA-DE-COMPRAS.en.md): what to buy, with quantities, estimated prices, and links.
3. [LIGACAO.en.md](LIGACAO.en.md): how to connect the wires, with the wiring diagram and workbench prep steps. The Arduino program is in the firmware folder.

Online guide: https://inematds.github.io/robos-impressos/guia/en/dino/
